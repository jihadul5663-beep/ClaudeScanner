package com.example.portscanner

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.portscanner.databinding.ItemPortResultBinding

class ResultsAdapter : RecyclerView.Adapter<ResultsAdapter.ViewHolder>() {

    private val results = mutableListOf<PortResult>()

    fun submit(result: PortResult) {
        results.add(result)
        results.sortWith(compareBy({ it.ip }, { it.port }, { it.protocol }))
        notifyDataSetChanged()
    }

    fun clear() {
        results.clear()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemPortResultBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(results[position])
    }

    override fun getItemCount(): Int = results.size

    class ViewHolder(private val binding: ItemPortResultBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(result: PortResult) {
            binding.tvServiceName.text = result.serviceName

            val stateLabel = if (result.state == "OPEN|FILTERED") "open|filtered" else "open"
            binding.tvMeta.text = "${result.protocol} · ${result.ip} · $stateLabel"
            binding.tvPortNumber.text = result.port.toString()

            binding.statusDot.setBackgroundResource(
                if (result.state == "OPEN|FILTERED") R.drawable.dot_ambiguous
                else R.drawable.dot_open
            )

            if (!result.banner.isNullOrBlank()) {
                binding.tvBanner.text = result.banner
                binding.tvBanner.visibility = View.VISIBLE
            } else {
                binding.tvBanner.visibility = View.GONE
            }
        }
    }
}
