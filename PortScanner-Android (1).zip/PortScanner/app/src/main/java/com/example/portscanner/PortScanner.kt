package com.example.portscanner

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.isActive
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.PortUnreachableException
import java.net.Socket
import java.net.SocketTimeoutException
import kotlin.coroutines.coroutineContext

enum class Protocol { TCP, UDP }

/**
 * Result of probing a single port on a single host.
 *
 * [state] is "OPEN" for a confirmed-open port (TCP handshake succeeded, or a
 * UDP service actually replied), or "OPEN|FILTERED" for UDP ports where we
 * sent a probe and got no response and no ICMP unreachable — with UDP that's
 * inherently ambiguous (the packet could have been silently dropped by a
 * firewall, or the service just doesn't respond to unsolicited/garbage data).
 */
data class PortResult(
    val ip: String,
    val port: Int,
    val protocol: String,
    val serviceName: String,
    val banner: String? = null,
    val state: String = "OPEN"
)

object PortScanner {

    // Common TCP ports mapped to the service that conventionally runs there.
    val COMMON_TCP_PORTS: Map<Int, String> = linkedMapOf(
        20 to "FTP (Data)", 21 to "FTP (Control)", 22 to "SSH", 23 to "Telnet",
        25 to "SMTP", 53 to "DNS", 80 to "HTTP", 110 to "POP3", 111 to "RPCbind",
        135 to "MS RPC", 139 to "NetBIOS Session", 143 to "IMAP", 179 to "BGP",
        389 to "LDAP", 443 to "HTTPS", 445 to "SMB", 465 to "SMTPS", 514 to "Syslog",
        515 to "LPD/Printer", 548 to "AFP", 554 to "RTSP", 587 to "SMTP (Submission)",
        631 to "IPP/CUPS", 636 to "LDAPS", 873 to "rsync", 993 to "IMAPS",
        995 to "POP3S", 1080 to "SOCKS Proxy", 1194 to "OpenVPN", 1433 to "MS SQL Server",
        1521 to "Oracle DB", 1723 to "PPTP", 1883 to "MQTT", 2049 to "NFS",
        2082 to "cPanel", 2083 to "cPanel (SSL)", 2222 to "SSH (Alt)", 27017 to "MongoDB",
        3000 to "Dev Server (Node/React)", 3128 to "Squid Proxy", 3306 to "MySQL",
        3389 to "RDP", 3690 to "SVN", 4433 to "HTTPS (Alt)", 5000 to "UPnP / Dev Server",
        5060 to "SIP", 5432 to "PostgreSQL", 5900 to "VNC", 5985 to "WinRM (HTTP)",
        5986 to "WinRM (HTTPS)", 6379 to "Redis", 6667 to "IRC", 8000 to "HTTP (Alt)",
        8080 to "HTTP Proxy / Web", 8443 to "HTTPS (Alt)", 8888 to "HTTP (Alt)",
        9000 to "PHP-FPM / Dev", 9090 to "WebSocket/Admin", 9200 to "Elasticsearch",
        11211 to "Memcached", 32400 to "Plex Media Server"
    )

    // Common UDP ports — a different set of conventions than TCP.
    val COMMON_UDP_PORTS: Map<Int, String> = linkedMapOf(
        53 to "DNS", 67 to "DHCP Server", 68 to "DHCP Client", 69 to "TFTP",
        111 to "RPCbind", 123 to "NTP", 137 to "NetBIOS Name", 138 to "NetBIOS Datagram",
        161 to "SNMP", 162 to "SNMP Trap", 319 to "PTP Event", 320 to "PTP General",
        500 to "IKE/IPSec", 514 to "Syslog", 520 to "RIP", 623 to "IPMI",
        1194 to "OpenVPN", 1434 to "MS SQL Monitor", 1900 to "SSDP/UPnP",
        4500 to "IPSec NAT-T", 5353 to "mDNS", 33434 to "traceroute"
    )

    fun serviceNameFor(port: Int, protocol: Protocol): String =
        if (protocol == Protocol.TCP) COMMON_TCP_PORTS[port] ?: "Unknown"
        else COMMON_UDP_PORTS[port] ?: "Unknown"

    /**
     * Expands CIDR notation (e.g. "192.168.1.0/24") into a list of usable
     * host IPs, excluding the network and broadcast addresses for prefixes
     * /30 or shorter. Returns an empty list if [cidr] isn't valid IPv4 CIDR.
     */
    fun expandCidr(cidr: String, maxHosts: Int = 1024): List<String>? {
        val parts = cidr.split("/")
        if (parts.size != 2) return null
        val prefix = parts[1].toIntOrNull() ?: return null
        if (prefix !in 0..32) return null
        val baseInt = ipToLong(parts[0]) ?: return null

        val hostBits = 32 - prefix
        val hostCount = if (hostBits >= 31) 1L else (1L shl hostBits)
        val networkBase = baseInt and (0xFFFFFFFFL shl hostBits)

        val start = if (hostBits >= 2) 1L else 0L
        val end = if (hostBits >= 2) hostCount - 2 else hostCount - 1
        if (end - start + 1 > maxHosts) return null

        val addresses = mutableListOf<String>()
        for (i in start..end) {
            addresses.add(longToIp(networkBase + i))
        }
        return addresses
    }

    private fun ipToLong(ip: String): Long? {
        val octets = ip.trim().split(".")
        if (octets.size != 4) return null
        var result = 0L
        for (octet in octets) {
            val value = octet.toIntOrNull() ?: return null
            if (value !in 0..255) return null
            result = (result shl 8) or value.toLong()
        }
        return result
    }

    private fun longToIp(value: Long): String {
        return "${(value shr 24) and 0xFF}.${(value shr 16) and 0xFF}." +
                "${(value shr 8) and 0xFF}.${value and 0xFF}"
    }

    /**
     * Scans [hosts] x [ports] for the given [protocol]. Work is chunked and
     * run concurrently. [onProgress] reports (completedUnits, totalUnits)
     * across the whole hosts*ports space so a subnet sweep shows one
     * continuous progress bar rather than resetting per host.
     */
    suspend fun scan(
        scope: CoroutineScope,
        hosts: List<String>,
        ports: List<Int>,
        protocol: Protocol,
        grabBanners: Boolean,
        timeoutMs: Int = 400,
        concurrency: Int = 80,
        onHostStart: (String) -> Unit = {},
        onPortOpen: (PortResult) -> Unit,
        onProgress: (completed: Int, total: Int) -> Unit
    ) {
        val totalUnits = hosts.size * ports.size
        var completedUnits = 0
        for (host in hosts) {
            if (!coroutineContext.isActive) return
            onHostStart(host)
            ports.chunked(concurrency).forEach { chunk ->
                if (!coroutineContext.isActive) return
                val deferreds = chunk.map { port ->
                    scope.async(Dispatchers.IO) {
                        probePort(host, port, protocol, grabBanners, timeoutMs)?.let { onPortOpen(it) }
                    }
                }
                deferreds.awaitAll()
                completedUnits += chunk.size
                onProgress(completedUnits, totalUnits)
            }
        }
    }

    private fun probePort(
        ip: String,
        port: Int,
        protocol: Protocol,
        grabBanners: Boolean,
        timeoutMs: Int
    ): PortResult? {
        return when (protocol) {
            Protocol.TCP -> {
                if (!isTcpPortOpen(ip, port, timeoutMs)) return null
                val banner = if (grabBanners) grabBanner(ip, port, timeoutMs) else null
                PortResult(ip, port, "TCP", serviceNameFor(port, Protocol.TCP), banner, "OPEN")
            }
            Protocol.UDP -> {
                val state = probeUdpPort(ip, port, timeoutMs) ?: return null
                PortResult(ip, port, "UDP", serviceNameFor(port, Protocol.UDP), null, state)
            }
        }
    }

    private fun isTcpPortOpen(ip: String, port: Int, timeoutMs: Int): Boolean {
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(ip, port), timeoutMs)
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    /**
     * UDP has no handshake, so "open" can't be confirmed the way TCP can.
     * Strategy: send a protocol-appropriate probe, then:
     *  - a real reply  -> "OPEN" (something is definitely listening)
     *  - an ICMP port-unreachable -> port is closed, return null (not open)
     *  - silence/timeout -> "OPEN|FILTERED" (ambiguous, same as nmap reports)
     */
    private fun probeUdpPort(ip: String, port: Int, timeoutMs: Int): String? {
        return try {
            DatagramSocket().use { socket ->
                socket.soTimeout = timeoutMs
                val address = InetAddress.getByName(ip)
                val payload = udpProbePayload(port)
                socket.send(DatagramPacket(payload, payload.size, address, port))

                val buf = ByteArray(512)
                val receivePacket = DatagramPacket(buf, buf.size)
                try {
                    socket.receive(receivePacket)
                    "OPEN"
                } catch (e: SocketTimeoutException) {
                    "OPEN|FILTERED"
                }
            }
        } catch (e: PortUnreachableException) {
            null // ICMP told us definitively: nothing is listening
        } catch (e: Exception) {
            null
        }
    }

    private fun udpProbePayload(port: Int): ByteArray = when (port) {
        53 -> byteArrayOf( // minimal DNS query for the root domain, type A
            0x00, 0x00, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x01
        )
        123 -> ByteArray(48).also { it[0] = 0x1B } // NTP client request (LI=0,VN=3,Mode=3)
        1900 -> ("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\n" +
                "MAN: \"ssdp:discover\"\r\nMX: 1\r\nST: ssdp:all\r\n\r\n").toByteArray()
        else -> byteArrayOf(0x00) // generic best-effort nudge for everything else
    }

    /**
     * Attempts to read a service banner on a TCP port that's already known
     * to be open. Many services (SSH, FTP, SMTP, POP3, IMAP) send a greeting
     * line unprompted; others (HTTP) need a nudge first. Best-effort only —
     * returns null if nothing is read within the timeout.
     */
    private fun grabBanner(ip: String, port: Int, timeoutMs: Int): String? {
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(ip, port), timeoutMs)
                socket.soTimeout = timeoutMs
                val input = BufferedReader(InputStreamReader(socket.getInputStream()))

                var banner: String? = try {
                    input.readLine()
                } catch (e: SocketTimeoutException) {
                    null
                }

                if (banner.isNullOrBlank()) {
                    val probe = bannerProbeFor(port)
                    if (probe != null) {
                        socket.getOutputStream().apply {
                            write(probe.toByteArray())
                            flush()
                        }
                        banner = try {
                            input.readLine()
                        } catch (e: Exception) {
                            null
                        }
                    }
                }
                banner?.trim()?.take(140)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun bannerProbeFor(port: Int): String? = when (port) {
        80, 8000, 8080, 8888, 3000, 5000, 9090 -> "HEAD / HTTP/1.0\r\n\r\n"
        else -> null
    }
}
