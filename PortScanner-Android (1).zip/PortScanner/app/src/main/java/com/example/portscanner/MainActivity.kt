package com.example.portscanner

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.portscanner.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ResultsAdapter
    private var scanJob: Job? = null

    // Safety caps so a fat-fingered subnet + full port range can't hang the
    // phone for hours or hammer a network. These are UI-level guardrails,
    // not protocol limits.
    private val maxHostsInSubnet = 256      // /24 or smaller
    private val maxPortsInRange = 5000
    private val maxTotalProbeUnits = 40000  // hosts * ports (per protocol pass)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = ResultsAdapter()
        binding.rvResults.layoutManager = LinearLayoutManager(this)
        binding.rvResults.adapter = adapter

        binding.btnScan.setOnClickListener {
            if (scanJob?.isActive == true) {
                stopScan()
            } else {
                startScan()
            }
        }
    }

    private fun startScan() {
        val rawTarget = binding.etIpAddress.text?.toString()?.trim().orEmpty()
        if (rawTarget.isEmpty()) {
            binding.tilIpAddress.error = "Enter an IP, hostname, or CIDR range"
            return
        }

        val hosts: List<String>
        if (rawTarget.contains("/")) {
            val expanded = PortScanner.expandCidr(rawTarget, maxHostsInSubnet)
            if (expanded == null) {
                binding.tilIpAddress.error = "Invalid CIDR, or subnet too large (max /24)"
                return
            }
            hosts = expanded
        } else {
            if (!isValidIpOrHost(rawTarget)) {
                binding.tilIpAddress.error = "Enter a valid IP address, hostname, or CIDR"
                return
            }
            hosts = listOf(rawTarget)
        }
        binding.tilIpAddress.error = null

        val ports: List<Int> = if (binding.cbCommonPortsOnly.isChecked) {
            val tcp = PortScanner.COMMON_TCP_PORTS.keys
            val udp = PortScanner.COMMON_UDP_PORTS.keys
            (tcp + udp).toSortedSet().toList()
        } else {
            val start = binding.etStartPort.text?.toString()?.toIntOrNull() ?: 1
            val end = binding.etEndPort.text?.toString()?.toIntOrNull() ?: 1024
            if (start < 1 || end > 65535 || start > end) {
                Toast.makeText(this, "Port range must be between 1 and 65535", Toast.LENGTH_SHORT).show()
                return
            }
            if (end - start > maxPortsInRange) {
                Toast.makeText(this, "Range too large — please use $maxPortsInRange ports or fewer", Toast.LENGTH_SHORT).show()
                return
            }
            (start..end).toList()
        }

        val protocolsToRun: List<Protocol> = when (binding.rgProtocol.checkedRadioButtonId) {
            binding.rbUdp.id -> listOf(Protocol.UDP)
            binding.rbBoth.id -> listOf(Protocol.TCP, Protocol.UDP)
            else -> listOf(Protocol.TCP)
        }

        val totalUnits = hosts.size.toLong() * ports.size.toLong() * protocolsToRun.size.toLong()
        if (totalUnits > maxTotalProbeUnits) {
            Toast.makeText(
                this,
                "That's ${totalUnits} probes — narrow the host range, port range, or protocol to keep this fast",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        val grabBanners = binding.cbGrabBanners.isChecked

        adapter.clear()
        binding.progressBar.visibility = View.VISIBLE
        binding.progressBar.progress = 0
        binding.tvStatus.text = "Preparing to scan ${hosts.size} host(s), ${ports.size} port(s)…"
        binding.btnScan.text = "Stop Scan"

        scanJob = lifecycleScope.launch {
            var openCount = 0
            try {
                for (protocol in protocolsToRun) {
                    if (!isActive) break
                    PortScanner.scan(
                        scope = this,
                        hosts = hosts,
                        ports = ports,
                        protocol = protocol,
                        grabBanners = grabBanners,
                        onHostStart = { host ->
                            runOnUiThread {
                                binding.tvStatus.text = "Scanning $host ($protocol)…"
                            }
                        },
                        onPortOpen = { result ->
                            openCount++
                            runOnUiThread {
                                adapter.submit(result)
                            }
                        },
                        onProgress = { completed, total ->
                            runOnUiThread {
                                val pct = if (total == 0) 100 else (completed * 100) / total
                                binding.progressBar.progress = pct
                            }
                        }
                    )
                }
                withContext(Dispatchers.Main) {
                    binding.tvStatus.text =
                        if (openCount == 0) "Scan complete — no open ports found"
                        else "Scan complete — $openCount open port(s) found across ${hosts.size} host(s)"
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    binding.tvStatus.text = "Scan failed: ${e.message}"
                }
            } finally {
                withContext(Dispatchers.Main) {
                    binding.progressBar.visibility = View.GONE
                    binding.btnScan.text = "Start Scan"
                }
            }
        }
    }

    private fun stopScan() {
        scanJob?.cancel()
        binding.tvStatus.text = "Scan cancelled"
        binding.progressBar.visibility = View.GONE
        binding.btnScan.text = "Start Scan"
    }

    private fun isValidIpOrHost(input: String): Boolean {
        if (input.isEmpty()) return false
        val ipRegex = Regex(
            "^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$"
        )
        val hostRegex = Regex("^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$")
        return ipRegex.matches(input) || hostRegex.matches(input)
    }
}
