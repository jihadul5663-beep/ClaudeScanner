# Port Scanner (Android)

A simple Android app (Kotlin) that scans an IP address for open TCP ports and
shows the commonly-associated service name for each open port (e.g. 22 → SSH,
80 → HTTP, 3306 → MySQL).

## ⚠️ Legal / ethical note
Only scan devices and networks you own or have explicit permission to test.
Scanning devices you don't control without authorization can violate
computer-misuse laws and the terms of service of ISPs/networks. This app is
intended for personal network administration and security learning (e.g.
auditing your own home router, home lab, or devices on a network you manage).

## How it works
- **UI**: Enter a single IP/hostname, or CIDR notation (e.g. `192.168.1.0/24`)
  to sweep an entire subnet. Pick a port range or use "common ports only"
  fast mode. Choose TCP, UDP, or Both. Optionally grab banners.
- **TCP scanning**: For each port, the app attempts a raw TCP `Socket`
  connection with a short timeout (400ms). If the connection succeeds, the
  port is open. This is a classic "TCP connect scan" — the same technique
  `nmap -sT` uses.
- **UDP scanning**: UDP has no handshake, so "open" can't be confirmed the
  way TCP can. The app sends a protocol-appropriate probe (a real DNS query
  for port 53, an NTP client request for port 123, an SSDP M-SEARCH for port
  1900, a generic nudge otherwise) and classifies the result the same way
  `nmap -sU` does:
  - a real reply → **open**
  - an ICMP "port unreachable" → **closed** (not shown)
  - silence → **open|filtered** (ambiguous — could be a firewall dropping
    the packet, or a service that just ignores unsolicited data)
- **Subnet sweep**: CIDR input is expanded into individual host IPs
  (network/broadcast addresses excluded), and each host is scanned in turn.
  Capped at /24 (254 hosts) from the UI to keep scans finishing in a
  reasonable time on a phone's radio.
- **Banner grabbing**: On open TCP ports, if enabled, the app reads whatever
  the service sends first (SSH, FTP, SMTP, POP3, IMAP all greet
  unprompted), or sends a minimal `HEAD / HTTP/1.0` nudge for likely HTTP
  ports and reads the response's first line. This often reveals the real
  software/version rather than just guessing from the port number.
- **Service names**: Open ports are also matched against built-in tables of
  well-known TCP and UDP ports (IANA-style assignments) for a friendly
  fallback name when no banner is available or applicable.
- **Concurrency & safety caps**: Ports are scanned in parallel batches
  (Kotlin coroutines) with a live progress bar. To keep a phone from being
  tied up for hours (or accidentally hammering a network), the UI caps
  subnets at /24, custom port ranges at 5000 ports, and total probes
  (hosts × ports × protocols) at 40,000 per scan — narrow your target if
  you hit that limit.

## Project structure
```
PortScanner/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml          # INTERNET + network state permissions
│       ├── java/com/example/portscanner/
│       │   ├── MainActivity.kt          # UI wiring, input validation, scan lifecycle
│       │   ├── PortScanner.kt           # Core scan logic + common-ports table
│       │   └── ResultsAdapter.kt        # RecyclerView adapter for results list
│       └── res/                         # Layouts, colors, launcher icon
├── build.gradle
├── settings.gradle
└── gradle/wrapper/gradle-wrapper.properties
```

## Building it
1. Open the `PortScanner/` folder in **Android Studio** (Hedgehog or newer)
   and let it sync Gradle — it will download the wrapper automatically.
2. Or from the command line, generate the wrapper jar once via
   `gradle wrapper` (requires Gradle installed), then run:
   ```
   ./gradlew assembleDebug
   ```
   The APK will be at `app/build/outputs/apk/debug/app-debug.apk`.
3. Minimum SDK is 24 (Android 7.0), target/compile SDK 34.

## Using the app
1. Enter a target IP (e.g. your router at `192.168.1.1`), a hostname, or a
   CIDR range (e.g. `192.168.1.0/24`) to sweep a whole subnet.
2. Leave "Scan common ports only" checked for a quick scan of well-known
   ports, or uncheck it and set a custom start/end port range.
3. Choose **TCP**, **UDP**, or **Both**.
4. Optionally check "Grab banners on open TCP ports" for extra detail on
   what's actually running (slower, since it waits for a response on each
   open port).
5. Tap **Start Scan**. Open ports appear in the list live as they're found —
   protocol, IP, port, guessed service, open/open|filtered state, and any
   banner text. Tap **Stop Scan** to cancel early.

## Extending it further
- **Host discovery / ping sweep**: currently every host in a CIDR range is
  port-scanned directly; a fast "is this host even up" pre-check (e.g. probe
  one or two common ports) could skip dead hosts and speed up large subnets.
- **IPv6 support**: CIDR expansion and validation are IPv4-only right now.
- **Export results**: save scan results to CSV/JSON for record-keeping.
